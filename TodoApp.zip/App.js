import "./App.css";
import { useState, useRef, useEffect } from "react";
import Header from "./component/Header";
import TodoEditor from "./component/TodoEditor";
import TodoList from "./component/TodoList";

const mockTodo = [
  {
    id: 0,
    isDone: false,
    content: "React 공부하기",
    createdDate: new Date().getTime(),
  },
  {
    id: 1,
    isDone: false,
    content: "영화보기",
    createdDate: new Date().getTime(),
  },
  {
    id: 2,
    isDone: false,
    content: "한강가서 산책하기",
    createdDate: new Date().getTime(),
  },
];

function App() {
  const [todo, setTodo] = useState(mockTodo);
  const idRef = useRef(3);

  // 새로운 Todo 생성
  const onCreate = (content) => {
    const newItem = {
      id: idRef.current,
      content,
      isDone: false,
      createdDate: new Date().getTime(),
    };
    setTodo((prevTodos) => [newItem, ...prevTodos]);
    idRef.current += 1;
  };

  // 체크 상태 변경
  const onUpdate = (targetId) => {
    setTodo((prevTodos) =>
      prevTodos.map((it) =>
        it.id === targetId ? { ...it, isDone: !it.isDone } : it
      )
    );
  };

  // Todo 삭제
  const onDelete = (targetId) => {
    setTodo((prevTodos) => prevTodos.filter((it) => it.id !== targetId));
  };

  // 일정 시간 후 체크된 항목 삭제
  useEffect(() => {
    const timers = [];
    todo.forEach((todoItem) => {
      if (todoItem.isDone) {
        const timeoutId = setTimeout(() => {
          setTodo((prevTodos) => prevTodos.filter((t) => t.id !== todoItem.id));
        }, 5000); // 체크된 항목은 5초 후에 삭제
        timers.push(timeoutId);
      }
    });
    // 컴포넌트가 언마운트되면 타이머 정리
    return () => {
      timers.forEach((timeoutId) => clearTimeout(timeoutId));
    };
  }, [todo]);

  // 체크된 항목과 체크되지 않은 항목으로 나누기
  const activeTodos = todo.filter((it) => !it.isDone);
  const completedTodos = todo.filter((it) => it.isDone);

  return (
    <div className="App">
      <Header />
      <TodoEditor onCreate={onCreate} />
      <h2>Todo List 🌱</h2>
      <TodoList todo={activeTodos} onUpdate={onUpdate} onDelete={onDelete} />

      {completedTodos.length > 0 && (
        <div className="completed-section">
          <h2>Completed Todo 🌱</h2>
          <p className="delete-info">(5초 후에 삭제됩니다)</p>
          <TodoList todo={completedTodos} onUpdate={onUpdate} onDelete={onDelete} />
        </div>
      )}
    </div>
  );
}

export default App;
